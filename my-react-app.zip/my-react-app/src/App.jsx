import Header from "./components/Header"
import User from "./components/User"
import Counter from "./components/Counter"
import ProductCart from "./components/ProductCard"




const App = () => {
  const firstname = "Iron"
  const lastname = "Man"
  const age = 45
  return (
    <>
    
    <Header />
    <div class="body">
    <ProductCart 
    img='https://rukminim2.flixcart.com/image/832/832/xif0q/backpack/x/5/4/8-casual-laptop-backpack-for-men-women-boys-girls-office-14-2043-original-imagvrb8dvbb8fau.jpeg?q=70&crop=false'
    name=' Back pack'
    desc="Large 70 L Backpack UNISEX WaterProof Mountain Rucksack/Hiking/Trekking/Camping Bag/Travel  (Grey)"
    price="₹399"
    strikePrice='₹1,999'
/>
<ProductCart 
    img='https://m.media-amazon.com/images/I/41p7Iq8lLyL.jpg'
    name=' BABYDOLL'
    desc="BABYDOLL 25 Liters with Spacious compartments School/College/Tuition/Travelling Bag for Girls & Women | Water Resistant & Lightweight Backpack"
    price="₹549"
    strikePrice='₹1,999'
/>
<ProductCart 
    img='https://m.media-amazon.com/images/I/41C1yDe7HBL._SY300_SX300_.jpg'
    name=' FUR JADEN'
    desc="Large 70 L Backpack UNISEX WaterProof Mountain Rucksack/Hiking/Trekking/Camping Bag/Travel  (Grey)"
    price="₹699"
    strikePrice='₹1,999'
/>
<ProductCart 
    img='https://m.media-amazon.com/images/I/71CSy0R6-8L._SX679_.jpg'
    name=' The Purple Tree'
    desc="The Purple Tree Multifunction Waterproof Laptop Travel Backpack with Shoe Compartment, Shoulder Bag, 35 L Laptop Backpack with USB Charging"
    price="₹2,599"
    strikePrice='₹3999'
/>
</div>
    <h1>App component</h1>
    <p>sbdncibidbvi</p>
   <User age={age}
    fname={firstname} 
    lname={lastname}/>

<Counter/>

  </>
  )
}

export default App;
