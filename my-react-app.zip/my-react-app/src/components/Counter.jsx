
import { useEffect, useState } from "react"


const Counter =()=>{
     const [count,setCount]=useState(10)
     const [count1,setCount1]=useState(0)
     useEffect(()=>{
        console.log('effect')
     },[count])

    const increment =()=>{
    setCount(count + 1)
}
const increment1=()=>{
    setCount1(count + 1)
}


    const decrement =()=>
    {
          if(count>0){
            setCount(count-1)
          }
          else{
            alert('Count is Already 0')
          }
    }
    
    return (
       
        <>
        <button onClick={increment}>+</button>
        <button onClick={increment1}>+</button> <h1>Count:{count}</h1>
       
        <button onClick={decrement}>-</button>

</>
    )
}

export default Counter