const Header = () => {
  return (
    <header>
      <div className="nav">
        <div>logo</div>
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
      </div>
    </header>
  )
}

export default Header
