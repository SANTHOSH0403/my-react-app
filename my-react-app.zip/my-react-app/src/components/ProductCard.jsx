const ProductCart = (props)=>{
    return(
        <div class="body">
        <div class="product-card">
            <img class ="product-img" src={props.img}/>
            <div class="product-name" >{props.name}</div>
            <div class="product-desc" >{props.desc}</div>
        <div>
        <span class="price">{props.price}</span>
        <span class="strike-price">{props.strikePrice}</span>
        </div>
        </div>
        </div>
    )
}
export default ProductCart