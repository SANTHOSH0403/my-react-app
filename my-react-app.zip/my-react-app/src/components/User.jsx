
const User = (props) => {
    console.log(props);
    
    return (
      <>
        <h2>Name: {`${props.fname} ${props.lname}`}</h2>
        <h2>Age: {props.age}</h2>
        <h2>{2 + 3}</h2>
      </>
    )
  }

  export default User